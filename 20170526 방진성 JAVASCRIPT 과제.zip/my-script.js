


function openNav() {
  document.getElementById("mySidenav").style.width = "250px"
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0"
}


var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) { slideIndex = 1 }
  if (n < 1) { slideIndex = slides.length }
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex - 1].style.display = "block";
  dots[slideIndex - 1].className += " active";
}


function myFunction() {
  var sum_value = document.getElementById("sum_value");

  var x = document.getElementById("mySelect");
  var xtext = x.options[x.selectedIndex].text;
  var xval = x.options[x.selectedIndex].value;
  
  
  var ul = document.getElementById("ul_list");

  var child = ul.childNodes;
  for(var k=0; k<child.length; k++){
    if(child[k].id==xval){
      return;
    }
  }
  
  var li = document.createElement("li");
  li.setAttribute("id", xval)

  var p = document.createElement("p");
  p.innerHTML = xtext;
  p.setAttribute("id", "demo");

  var input = document.createElement("input");
  input.setAttribute("type", "text");
  input.setAttribute("value", "1");
  input.setAttribute("min", "1");
  input.setAttribute("id", "count");

  var button_plus = document.createElement("button");
  button_plus.setAttribute("value", "+");
  button_plus.setAttribute("onclick", "plus()");
  button_plus.innerHTML = "+";
  button_plus.addEventListener('click', function (event) {
    input.value++;
    if (li.id == "A") {
      span.innerHTML = Number(span.innerHTML) + 39800;
      sum_value.innerHTML = Number(sum_value.innerHTML) + 39800;
    }
    else if (li.id == "B") {
      span.innerHTML = Number(span.innerHTML) + 49800;
      sum_value.innerHTML = Number(sum_value.innerHTML) + 49800;
    }
    else if (li.id == "C") {
      span.innerHTML = Number(span.innerHTML) + 59800;
      sum_value.innerHTML = Number(sum_value.innerHTML) + 59800;
    }

  });

  var button_minus = document.createElement("button");
  button_minus.setAttribute("value", "-");
  button_minus.setAttribute("onclick", "minus()");
  button_minus.innerHTML = "-";
  button_minus.addEventListener('click', function (event) {
    if (input.value > 1) {
      input.value--;
      if (li.id == "A") {
        span.innerHTML = Number(span.innerHTML) - 39800;
        sum_value.innerHTML = Number(sum_value.innerHTML) - 39800;
      }
      else if (li.id == "B") {
        span.innerHTML = Number(span.innerHTML) - 49800;
        sum_value.innerHTML = Number(sum_value.innerHTML) - 49800;
      }
      else if (li.id == "C") {
        span.innerHTML = Number(span.innerHTML) - 59800;
        sum_value.innerHTML = Number(sum_value.innerHTML) - 59800;
      }
    }

  });

  var button_delete = document.createElement("button");
  button_delete.innerHTML = "X";

  var span = document.createElement("span");
  if (li.id == "A") {
    span.innerHTML = 39800;
    sum_value.innerHTML = Number(sum_value.innerHTML) + 39800;
  }
  else if (li.id == "B") {
    span.innerHTML = 49800;
    sum_value.innerHTML = Number(sum_value.innerHTML) + 49800;
  }
  else if (li.id == "C") {
    span.innerHTML = 59800;
    sum_value.innerHTML = Number(sum_value.innerHTML) + 59800;
  }
  var span_Won = document.createElement("span");
  span_Won.innerHTML="원";

  ul.appendChild(li);
  li.appendChild(p);
  li.appendChild(input);
  li.appendChild(button_plus);
  li.appendChild(button_minus);
  button_delete.onclick = function () {
    button_delete.parentElement.remove();
    x.selectedIndex = "0";
    if (li.id == "A") {
      sum_value.innerHTML = Number(sum_value.innerHTML) - input.value * 39800;
    }
    else if (li.id == "B") {
      sum_value.innerHTML = Number(sum_value.innerHTML) - input.value * 49800;
    }
    else if (li.id == "C") {
      sum_value.innerHTML = Number(sum_value.innerHTML) - input.value * 59800;
    }
    

    return;
  }
  li.appendChild(button_delete);
  li.appendChild(span);
  li.appendChild(span_Won);

}