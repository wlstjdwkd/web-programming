package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Board;
import service.BoardService;

public class BoardController implements Controller {

	
	private final BoardService boardService = new BoardService();

	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();
		Board board = new Board();
		if (url.equals("/board/board-list")) {
			ArrayList<Board> boards = boardService.findBoards();

			modelAndView.setViewName("board/board-list");
			modelAndView.getModel().put("boards", boards);
		} else if (url.equals("/board/detail")) {
			board.setId(Long.parseLong(request.getParameter("id")));
			board.setTitle(request.getParameter("title"));
			board.setContents(request.getParameter("contents"));
			board = boardService.detail(board);
			modelAndView.setViewName("board/detail");
			modelAndView.getModel().put("board", board);
			
			
		} else if (url.equals("/board/write")) {
			if (request.getMethod().equals("GET")) {
				modelAndView.setViewName("board/write");
			} else if (request.getMethod().equals("POST")) {
				board.setTitle(request.getParameter("title"));
				board.setWriter(request.getParameter("writer"));
				board.setContents(request.getParameter("contents"));
				
				boardService.write(board);
				modelAndView.setViewName("index");
				
			}

		} else if (url.equals("/board/delete")) {
			board.setId(Long.parseLong(request.getParameter("id")));
			boardService.delete(board);
			modelAndView.setViewName("index");
			
			
		} else if (url.equals("/board/update")) {
			if (request.getMethod().equals("GET")) {
				modelAndView.setViewName("board/update");
			} else if (request.getMethod().equals("POST")) {
				board.setId(Long.parseLong(request.getParameter("id")));
				board.setTitle(request.getParameter("title"));
				board.setWriter(request.getParameter("writer"));
				board.setContents(request.getParameter("contents"));

				boardService.update(board);
				
				modelAndView.setViewName("index");
		}
		} else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
